package BtcLevel_II;
//import BtcLevel_III.*;

class RUN_IMAGE
{
 public static void main(String args[])
 {
   ReciveDatFile rec=new ReciveDatFile();
   rec.runII();
   
   //Run_BTC_III obj5=new Run_BTC_III();
   //obj5.run("F"); 
 }
}