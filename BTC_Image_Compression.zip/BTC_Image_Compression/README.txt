Instal java: 

Please click run_BTC_Image_Compression_Algo.bat to run the algorithm

You need to download http://www.irfanview.com/
to view decoded pmg files

Batch file setting is batch file can not be downloaded:

set classpath=%classpath%..;C:\Users\Varun\Desktop\BTC_Image_Compression;C:\java\classes
cd BtcLevel_II
javac RUN_IMAGE.java
cd..
java BtcLevel_II.RUN_IMAGE
time

Input file name:
Please make sure to input file name with extention:
e.g. boat.dat

Output open the file using infra view to compare the file with the original in output folder.

Look for BTC.pdf for more detail about the algorithm

For mac class path may be set as follows:
...$ export CLASSPATH=${CLASSPATH}:/usrs/..... BTC_Image_Compression